//
//  ViewController.swift
//  headSensor
//
//  Created by Hall, Sean M. on 6/1/20.
//  Copyright © 2020 Hall, Sean M. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

